# Ansible Collection - netology.touch_module

Task example:

- name: Create file.
  netology.touch_module.touch_module:
    path: "{{ path }}"
    content: "{{ content }}"
  register: job_result

- debug:
    msg: "{{ job_result.message }}"

path: path to file include file name
content: file contents